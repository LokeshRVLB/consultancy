import React from 'react';
import { BrowserRouter as Switch, Route} from 'react-router-dom';

import Header from './components/utils/header/Header'
import Home from './components/home/Home';
import About from './components/AboutUs/AboutUs';
import Services from './components/services/Services'
import Contact from './components/contact/Contact'
import './App.css';
import Footer from './components/utils/footer/Footer'

function App() {

  let links = [
    {
      name: "Home",
      path: "/"
    },
    {
      name: "How we work",
      path: "/services"
    },
    {
      name: "Courses",
      path: "/about"
    },
    {
      name: "Placements",
      path: "/abouts"
    },
    {
      name: "Contact Us",
      path: "/contact"
    }
  ]
  return (
    <div>
      <Switch>
      <Header links={links} />
        <Route exact  path="/" component={Home} />
        <Route path="/about" component={About} />
        <Route path="/services" component={Services} />
        <Route path="/contact" component={Contact} />
        <Footer />
      </Switch>
    </div>
  );
}

export default App;
