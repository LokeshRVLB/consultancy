/**
 * It representing a Routes Page.
 * @CreatedOn 13/05/2019
 * @version 1.0
 * @author [Lokesh - 9160164239]
 */
import React from 'react';
import { Provider } from 'react-redux';
import { BrowserRouter as Router, Switch, Route, Redirect } from 'react-router-dom';
/**
 * page Components
 */

const Routes = (<Provider>
  <Router>
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/about" component={About} />
      <Route path="/services" component={Services} />
      <Route path="/contact" component={Contact} />
      <Redirect from="/test" to="/" />
    </Switch>
    <RequestReLogin />
  </Router>
</Provider>);

export default Routes;