import React from 'react'
import './Contact.css'

export default () => (
    <div className='container'>
        {/* <h1 className='brand'><span>Lawrence</span> Web Design</h1> */}
        {/* <h1 className="contactUs"> Contact Us </h1> */}

		<div className='wrapper animated bounceInLeft space'>
			<div className='company-info'>
				<h3>Adorein Consultancy Service</h3>
				<ul>
					<li><i className="fa fa-road"></i> Taramani P.411</li>
					<li><i className="fa fa-phone"></i> (555) 5555-5555</li>
					<li><i className="fa fa-envelope"></i> contact@adorein.com</li>
				</ul>
		</div>
		<div className='contact'>
			<h3>Email Us</h3>
			<form>
				<p>
					<input  type="text" name='name' placeholder='Name' /> 
				</p>

				<p >
					<input type="text" name='company' placeholder='Company' /> 
				</p>

				<p>
					<input type="email" name='email' placeholder='Email Address' /> 
				</p>

				<p className='full'>
					<textarea name="message" rows="5" placeholder='Message' ></textarea> 
				</p>

				<p className='full'>
					<button className="color">Submit</button>
				</p>
			</form>
		</div>
	</div>
    </div>
)