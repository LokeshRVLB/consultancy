import React from 'react'
import './HomeSlides.css'

export default () => {
    return (
        <div className="carousel-slide">
            <p className='carousel-slide-content'></p>
        </div>
    )
}