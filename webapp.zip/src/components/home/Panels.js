import React from 'react'
import './panel.css';

export default () => (
    <div className="panel-container">
        <div className="panel"> 
            <img className="panel-image" src="" />
            <p className="panel-title"><span className="span">CONSULTING</span></p>
            <p className="panel-body">Talent Acquisition strategy and processes have not been given the necessary importance and thought in strategic decision making. Process management and Recruitment consulting results in excellence in talent management</p>
        </div>
        <div className="panel">
            <img className="panel-image" src="" />
            <p className="panel-title"><span className="span">RPO</span></p>
            <p className="panel-body">Organizations need to consider various aspects of operations, finance, business and HR when making hiring decisions. Recruitment processes require different levels of expertise and a high level of focus on each specific process.</p>
        </div>
        <div className="panel">
            <img className="panel-image" src="" />
            <p className="panel-title"><span className="span" >BESPOKE HIRING</span></p>
            <p className="panel-body">Every organization is confronted with the continuously evolving challenges of hiring critical positions in a market place characterized by massive demand and a dearth of appropriate talent. </p>
        </div>  
    </div>)