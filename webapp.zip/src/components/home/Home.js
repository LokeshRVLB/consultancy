import React from 'react'
import HomeSlides from './HomeSlides'
import Panels from './Panels'
import Card from '../utils/card/Card'
import Story from '../utils/story/story'

import './home.css';

export default () => (<div>
    <HomeSlides/>
    <Card />
    <Story />
    <Panels />
    </div>)