import React from  'react';
import './Header.css';
import { Link } from 'react-router-dom';
import { withRouter } from "react-router";

const Header =  (props) => {
    console.log(props)
    let toggleSwitch = React.createRef()
    let mainNavigation = React.createRef()

    return (
        <nav className="navbar">
            <a href="#" className="logo">ADOREIN</a>
            
            <span className="navbar-toggle">
                <i className="fas fa-bars" 
                   ref={toggleSwitch}
                   onClick={() => mainNavigation.current.classList.toggle('active')}>hai</i>
            </span>
            
            <ul className="main-nav" ref={mainNavigation}>
                {props.links.map((link => link.path === props.location.pathname?<li className='nav-links-container'>
                    <a onClick={() => props.history.push(link.path)} className="nav-link selected">{link.name}</a>
                </li>:<li className='nav-links-container'>
                    <a onClick={() => props.history.push(link.path)} className="nav-link">{link.name}</a>
                </li>))}
            </ul>
        </nav>
    )
}

export default withRouter(Header);