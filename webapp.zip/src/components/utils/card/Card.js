import React from 'react'
import './Card.css'
import first from '../../../static/first.png'
import i3 from '../../../static/i3.png'
import images from '../../../static/search.png'
// import first from '../../../static/first.png'

export default () => {
    return (
    <div className="cardContainer">
        <div className="cus-card">
            <img className="icon" src={first} />
            <p className="cus-title">PROCESS OUTSOURCING</p>
            <p className="content">Refine your recruiting acumen with speed and efficiency.</p>
        </div>
        <div className="cus-card">
            <img className="icon" src={i3} />
            <p className="cus-title">TALENT ACQUASITION</p>
            <p className="content">Custom design your talent acquisition process with a team expertise.</p>
        </div>
        <div className="cus-card">
            <img className="icon" src={images} />
            <p className="cus-title">CONSULTING SERVICES</p>
            <p className="content">Innovate in hiring and develop adeptness to learn.</p>
        </div>
        <div className="cus-card">
            <img className="icon" src={first} />
            <p className="cus-title">TALENT ACQUASITION</p>
            <p className="content">Custom design your talent acquisition process with a team expertise.</p>
        </div>

    </div>
    )
}