import React from 'react'
import './Story.css'

export default () => {
    return (
        <div className='story'>
            <p className='story-title'><span>OUR SOLUTIONS</span></p>
            <p className='story-content'>With 9 years of experience of high quality recruitment and recruitment process outsourcing in India, Adorein is ideally positioned to act as a key facilitator in this phase of India's demand for leadership talent. The process of creating and defining important leadership roles, attracting and retaining key leadership talent in a fast paced economy which is expanding globally, is a complex challenge that we at Adorein are excited to solve.</p>
        </div>
    )
}