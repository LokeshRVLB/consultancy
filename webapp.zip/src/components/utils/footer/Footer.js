import React from 'react';
import './Footer.css';

export default () => {
  return (
    <div className="footer">
    <div className="container">     
        <div className="row">                       
            <div className="col-lg-4 col-sm-4 col-xs-12">
                <div className="single_footer">
                    <h4>Services</h4>
                    <ul>
                        <li><a href="#">Consulting</a></li>
                        <li><a href="#">RPO</a></li>
                        <li><a href="#">Bespoke Hiring </a></li>
                        <li><a href="#">University Hiring</a></li>
                        <li><a href="#">Executive Search</a></li>
                    </ul>
                </div>
            </div>
            <div className="col-md-4 col-sm-4 col-xs-12">
                <div className="single_footer single_footer_address">
                    <h4>Page Link</h4>
                    <ul>
                    <li><a href="#">Consulting</a></li>
                        <li><a href="#">RPO</a></li>
                        <li><a href="#">Bespoke Hiring </a></li>
                        <li><a href="#">University Hiring</a></li>
                        <li><a href="#">Executive Search</a></li>
                    </ul>
                </div>
            </div>
            <div className="col-md-4 col-sm-4 col-xs-12">
                <div className="social_profile">
                    <ul>
                        <li><a href="#"><i className="fab fa-facebook-f"></i></a></li>
                        <li><a href="#"><i className="fab fa-twitter"></i></a></li>
                        <li><a href="#"><i className="fab fa-google-plus-g"></i></a></li>
                        <li><a href="#"><i className="fab fa-instagram"></i></a></li>
                    </ul>
                </div>                          
            </div>       
        </div>
        <div className="row">
            <div className="col-lg-12 col-sm-12 col-xs-12">
                <p className="copyright">Copyright © 2019 <a href="#">freshthoughts infotech Pvt Ltd</a>.</p>
            </div>                
        </div>                
    </div>
</div>)
}